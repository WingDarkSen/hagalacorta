
window.onload = () => {
  const checkbox = document.getElementById('modeToggle');
  const storedMode = localStorage.getItem('darkMode');
  const autoDark = new Date().getHours() >= 18 || new Date().getHours() < 6;
  const isDark = storedMode === null ? autoDark : storedMode === 'true';

  document.body.classList.toggle('light-mode', !isDark);
  checkbox.checked = !isDark;

  checkbox.addEventListener('change', () => {
    const active = !checkbox.checked;
    document.body.classList.toggle('light-mode', !active);
    localStorage.setItem('darkMode', active);
  });
};

function generarURLCorta() {
  const urlOriginal = document.getElementById("input-url").value;
  try {
    new URL(urlOriginal); // valida la URL
  } catch {
    document.getElementById("resultado").innerText = "Por favor ingresa una URL válida.";
    return;
  }
  const hash = btoa(urlOriginal).slice(0, 6);
  const urlCorta = `https://hagalacorta.netlify.app/${hash}`;
  document.getElementById("resultado").innerHTML = `URL acortada: <a href="${urlOriginal}" target="_blank">${urlCorta}</a>`;
}
